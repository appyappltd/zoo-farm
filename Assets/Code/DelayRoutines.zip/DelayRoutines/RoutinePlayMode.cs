namespace DelayRoutines
{
    public enum RoutinePlayMode : byte
    {
        Continue,
        AtFirst
    }
}